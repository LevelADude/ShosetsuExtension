-- {"id":814,"version":"1.0.0","author":"Doomsdayrs"}
-- Direct ripooff of BestLightNovel
return Require("247truyen")("https://novelonlinefree.com", {
	id = 814,
	name = "NovelOnlineFree",
	shrinkURLNovel = "novel",
})
