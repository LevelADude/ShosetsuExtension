-- {"id":278,"ver":"1.0.2","libVer":"1.0.0","author":"TechnoJo4","dep":["NovelFull>=1.0.0"]}

return Require("NovelFull")("https://readnovelfull.com", {
	id = 278,
	name = "ReadNovelFull",
	imageURL = "https://github.com/shosetsuorg/extensions/raw/dev/icons/ReadNovelFull.png",
	genres = {},
	searchListSel = "list.list-novel.col-xs-12",
	appendURLToInfoImage = false,
})
