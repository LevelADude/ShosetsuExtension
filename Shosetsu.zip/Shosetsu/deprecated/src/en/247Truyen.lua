-- {"id":247,"version":"1.0.0","author":"TechnoJo4","repo":""}
-- Site made private

return Require("247truyen")("https://247truyen.com", {
	id = 247,
	name = "247Truyen",
	novelSearchPath = "search_manga",
	novelListPath = "danh_sach_truyen"
})
