-- {"id":1273,"ver":"1.0.3","libVer":"1.0.0","author":"TechnoJo4","dep":["WWVolare>=1.2.0"]}

return Require("WWVolare")(1273, "WuxiaWorld", "https://www.wuxiaworld.com", "#chapter-content",
		"https://github.com/shosetsuorg/extensions/raw/dev/icons/WuxiaWorld.png")
