return Require("NovelFull")("https://mnovelfree.com", {
	id = 249,
	name = "MNovelFree",
	imageURL = "https://github.com/shosetsuorg/extensions/raw/dev/icons/MNovelFree.png",
	genres = {},

	meta_offset = 0,
	ajax_hot = "/lists/popular",
	ajax_latest = "/lists/new-novels",
	ajax_chapters = "",
	searchTitleSel = ".truyen-title"
})
