-- {"id":510,"version":"1.0.0","author":"Doomsdayrs"}
-- Direct ripooff of BestLightNovel
return Require("247truyen")("https://novelonlinefull.com", {
	id = 510,
	name = "NovelOnlineFull",
	novelListingTitleClass = "",
	shrinkURLNovel = "novel",
})
