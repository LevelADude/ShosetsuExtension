-- {"id":1274,"ver":"1.0.3","libVer":"1.0.0","author":"TechnoJo4","dep":["WWVolare>=1.2.0"]}

return Require("WWVolare")(1274, "VolareNovels", "https://www.volarenovels.com", ".jfontsize_content",
		"https://github.com/shosetsuorg/extensions/raw/dev/icons/VolareNovels.png")
