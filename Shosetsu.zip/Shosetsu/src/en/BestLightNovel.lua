-- {"id":5,"ver":"2.0.2","libVer":"1.0.0","author":"TechnoJo4","dep":["247truyen>=1.1.1"]}

return Require("247truyen")("https://bestlightnovel.com", {
	id = 5,
	name = "BestLightNovel",
    imageURL = "https://github.com/shosetsuorg/extensions/raw/dev/icons/BestLightNovel.png",
})
