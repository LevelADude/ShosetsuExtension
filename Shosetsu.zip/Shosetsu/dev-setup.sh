#!/bin/bash

## Download lua documentation
rm _doc.lua
wget https://gitlab.com/shosetsuorg/kotlin-lib/-/raw/main/_doc.lua

## Download javascript documentation
#wget https://gitlab.com/shosetsuorg/kotlin-lib/-/raw/main/doc.js